<?php
// mengambil data tampilan dari controller, dengan nama variabel "content"
if($content)
{
	$this->load->view($content);
}