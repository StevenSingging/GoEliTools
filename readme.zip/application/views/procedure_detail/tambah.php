
<?php echo form_open(site_url('procedure_detail/tambah')) ?>

<div class="form-group row">
  <label for="procedure_id" class="col-sm-3 text-right">Pilih procedure</label>
  <div class="col-sm-9">
    <select name="procedure_id" class="form-control select2" required>
      <option value="">Pilih Procedure .....</option>
      <!-- Ambil data project dari Controller -->
      <?php foreach ($procedure as $procedure) { ?>
        <option value="<?php echo $procedure->procedure_id ?>">
         <?php echo $procedure->procedure_id ?> - <?php echo $procedure->procedure_desc ?> 
        </option>
      <?php } ?>
      }
    </select>
  </div>
</div>

<div class="form-group row">
  <label for="procedure_detail_no" class="col-sm-3 text-right">Procedure_detail_No</label>
  <div class="col-sm-9">
    <input type="text" name="procedure_detail_no" class="form-control" placeholder="procedure_detail" value="<?php echo set_value('procedure_detail_no') ?>" required>
  </div>
</div>


<div class="form-group row">
  <label for="procedure_detail" class="col-sm-3 text-right">Procedure_detail Description</label>
  <div class="col-sm-9">
    <input type="text" name="procedure_detail_desc" class="form-control" placeholder="procedure_detail" value="<?php echo set_value('procedure_detail_desc') ?>" required>
  </div>
</div>

<div class="form-group row">
  <label for="pre_condition" class="col-sm-3 text-right">Procedure Pre-Condition</label>
  <div class="col-sm-9">
    <input type="text" name="pre_condition" class="form-control" placeholder="procedure_detail" value="<?php echo set_value('pre_condition') ?>" required>
  </div>
</div>

<div class="form-group row">
  <label for="post_condition" class="col-sm-3 text-right">Procedure Post-Condition</label>
  <div class="col-sm-9">
    <input type="text" name="post_condition" class="form-control" placeholder="post_procedure" value="<?php echo set_value('post_condition') ?>" required>
  </div>
</div>

<div class="form-group row">
  <label for="formula" class="col-sm-3 text-right">Formula</label>
  <div class="col-sm-9">
    <input type="text" name="formula" class="form-control" placeholder="formula" value="<?php echo set_value('formula') ?>">
  </div>
</div>

<div class="form-group row">
  <label for="resources" class="col-sm-3 text-right">resources</label>
  <div class="col-sm-9">
    <input type="text" name="resources" class="form-control" placeholder="resources" value="<?php echo set_value('resources') ?>" >
  </div>
</div>


<div class="form-group row">
  <label for="procedure_detail" class="col-sm-3 text-right"></label>
  <div class="col-sm-9">
    <button type="btn btn-success" type="submit" name="submit" value="submit">
      <i class="fa fa-save"></i> Simpan Data
    </button>
    <button type="btn btn-default" type="reset" name="reset" value="reset">
      <i class="fa fa-times"></i> Reset
    </button>
    
  </div>
</div>

<a href="<?php echo site_url('procedure_detail') ?>" class="btn btn-success">
        <i class = "fa fa-backward"></i> Kembali
</a>
<?php echo form_close(); ?>