<div class="modal fade" id="modal-default">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title">Tambah Project Baru</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              
                            
              <div class="form-group row">
                  <label for="project_name" class="col-sm-3 col-form-label">Project Name</label>
                  <div class="col-sm-9">
                    <input type="text" name="project_name" class="form-control" placeholder="Project Name" value="<?php echo set_value('project_name') ?>" required>
                  </div>
              </div>


              <div class="form-group row">
                  <label for="project_desc" class="col-sm-3 col-form-label">Project Description</label>
                  <div class="col-sm-9">
                    <input type="text" name="project_desc" class="form-control" placeholder="Project Description" value="<?php echo set_value('project_desc') ?>" required>
                  </div>
              </div>

            </div>
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-default" data-dismiss="modal">
                <i class="fa fa-times"> </i> Tutup
              </button>
              
              <button type="submit" class="btn btn-primary">
                <i class="fa fa-save"></i> Simpan Data
              </button>
            </div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
      <!-- /.modal -->