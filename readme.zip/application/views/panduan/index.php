<div class="callout callout-info">
	<h3>Panduan Penggunaan Sistem Informasi</h3>
	<p>Di Bawah ini adalah Panduan yang dapat Anda gunakan. Anda bisa membacanya secara langsung atau mengunduhnya.</p>
</div>

<iframe src ="<?php echo base_url('assets/file/Panduan.pdf') ?>" width='1000' height='1000' allowfullscreen webkitallowfullscreen></iframe>