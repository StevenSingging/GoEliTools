<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	// load all table model
	public function __construct()
	{
		parent::__construct();
		// Panggil fungsi check login
		$this->my_login->check_login();

		 $this->load->model('project_model');
		 $this->load->model('stakeholder_model');
		 $this->load->model('project_stakeholder_model');
		 
		 $this->load->model('denyut_nadi_model');
		 $this->load->model('suhu_tubuh_model');
		 $this->load->model('user_model');
		 $this->load->model('pasien_model');

	}

	// load model, library dll
	//public function __construct()
	//{
	//	parent::__construct();
		// Panggil fungsi check login
	//	$this->my_login->check_login();
	//}

	// main page dashboard
	public function index()
	{
		// Data total per tabel
		$project 		= $this->project_model->total();
		$stakeholder	= $this->stakeholder_model->total();
		$project_stakeholder = $this->project_stakeholder_model->total();
		$pasien 		= $this->pasien_model->total();
		$user 			= $this->user_model->total();
		$denyut_nadi 	= $this->denyut_nadi_model->total();
		$suhu_tubuh 	= $this->suhu_tubuh_model->total();
		// End data total

		$data = array ('title'			 => 'Halaman Dashboard',
						'project'		=>$project,
						'stakeholder'	=>$stakeholder,
						'project_stakeholder' =>$project_stakeholder,
						'pasien'		=>$pasien,
						'user'			=>$user,
						'denyut_nadi'	=>$denyut_nadi,
						'suhu_tubuh'	=>$suhu_tubuh,
						'content'		=> 'dashboard/index'
					   );
		$this->load->view('layout/wrapper', $data, FALSE);
	}

}

/* End of file Dashboard.php */
/* Location: ./application/controllers/Dashboard.php */